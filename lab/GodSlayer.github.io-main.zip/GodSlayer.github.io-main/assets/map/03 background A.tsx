<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.5" tiledversion="1.7.1" name="03 background A" tilewidth="32" tileheight="32" tilecount="156" columns="13">
 <image source="../sprites/PlatformerSet1/Background/03 background A.png" width="426" height="384"/>
</tileset>
